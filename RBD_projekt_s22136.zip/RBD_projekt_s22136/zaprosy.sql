--1.1
--Wybieram id bufeta, w ktorym cena napoju jest wieksza niz 4 i mniejsza niz 8 
--i laczymy 1dwie kolumny napoj i jego cene
SELECT id_bufet, nopoj || '-' || cena_napoju ||' zl' "NAPOI-CENA"
FROM BUFET
WHERE cena_napoju BETWEEN 4 AND 8;

--1.2
--Wybieram id, ime,  i nazwisko tych osob, ktorych ime nie zaczyna sie na litere M lub A 
--i sortuje wedlug nazwiska w kolejnosci alfabetycznej. 
SELECT id, ime, nazwisko
FROM osoba
WHERE ime NOT LIKE 'M%' OR ime NOT Like 'A%'
Order BY nazwisko;

--1.3
--Wybieram adres, miasto i telefon z tabeli trampolina Center, 
--gdzie nazwa Centrum sklada sie z wiecej niz szesciu znakow
SELECT adres, miasto, telefon
FROM trampoliny_centrum 
WHERE nazwa NOT LIKE '______' ;

--1.4
--Wybieram id hal, nazwa,i pojemnosc  40 i 60. Lacze tabele HAL i TRAMPOLINY_CENTRUM
--Sortuje wedlug nazwy
SELECT id_hal, nazwa, pojemnosc
FROM HAL h INNER JOIN TRAMPOLINY_CENTRUM t ON h.id_centrum = t.id_centrum
WHERE pojemnosc IN (40, 60)
ORDER BY nazwa;

--1.5
--Wybieram miesieczna kwote wynagrodzenia tych pracowników, którzy sa powyzej 30.
SELECT SUM(wyplata) 
FROM osoba o INNER JOIN pracownik p
     ON o.id  = p.osoba_id 
     INNER JOIN zawod z
     ON z.id_zawod = p.id_zawod
Where wiek > 30;

--2.1
--Wybieram id pracownika z tabeli pracownik, ime z tabeli osoba, nazwy stanowiska i wyplaty z tabeli zawod. 
--Lacze trzy tabele i sortuje wynagrodzenie malejaco
SELECT  id_pracownik, ime, nazwa_stanowiska, wyplata
FROM osoba o INNER JOIN pracownik p
     ON o.id  = p.osoba_id 
     INNER JOIN zawod z
     ON z.id_zawod = p.id_zawod
Order by wyplata desc; 

--2.2
--Wybieram  sum wyplat menzy 5000 a 7000, nazwa_stanowiska i nazwiska posortowane alfabetycznie
SELECT o.ime, wyplata*12 "wyplata wszystkom za miesac"
FROM osoba o INNER JOIN pracownik p
     ON o.id  = p.osoba_id 
     INNER JOIN zawod z
     ON z.id_zawod = p.id_zawod
ORDER  BY  o.ime;
     

--2.3
--Wybieram ime, nazwisko, telefon i poczatek/koniec wizyty tych osob, telefon ktorych konczy sie na 8
--lacze tabele wizyta_kl, klient, osoba
SELECT ime, nazwisko, telefon, poczatek_wizyty|| ' / ' || koniec_wizyty " POCZATEK / KONIEC WIZYTY"
FROM  wizyta_kl w INNER JOIN klient k 
    ON w.id_klient = k.id_klient 
    INNER JOIN osoba o
    ON  k.id_klient = o.id
    WHERE telefon  LIKE '%8';


--2.4
--Wybieram  pojemnosc hali w centrum i wszystko z tabeli trampoliny_centrum, w nazwie których jest spacja 
--lacze tabele trampoliny_centrum i hal
SELECT t.*, pojemnosc 
FROM trampoliny_centrum t JOIN hal h 
    ON h.id_centrum = t.id_centrum
WHERE nazwa LIKE '% %';

--2.5
--Wpisz wiel, tytul stanowiska, na którym pracuje najbardziej dorosly czlowiek.
SELECT  nazwa_stanowiska, wiek
FROM osoba o INNER JOIN pracownik p
     ON o.id  = p.osoba_id 
     INNER JOIN zawod z
     ON z.id_zawod = p.id_zawod
     WHERE o.wiek = (SELECT MAX(wiek)
                        FROM osoba);                        
    

--3.1
--Wybieram ktore wartosci zarobkow sa powtarzane i ilu pracownikow je otrzymuje.
SELECT COUNT(1), wyplata
FROM zawod
GROUP BY wyplata
HAVING COUNT(1) > 1;

--3.2
--Wybierz stanowiska, na ktorych srednie zarobki nie wynosza 5000
SELECT AVG(wyplata), nazwa_stanowiska
FROM zawod
GROUP BY nazwa_stanowiska
HAVING AVG(wyplata) != 5000 AND AVG(wyplata)>= 6000;


--3.3
--wypiszemy min pojemnosc, i nazwe centrum
SELECT MIN(pojemnosc), nazwa
FROM trampoliny_centrum t, hal h 
   WHERE h.id_centrum = t.id_centrum
   AND pojemnosc = (SELECT MIN(pojemnosc)
                    FROM hal)
GROUP BY nazwa;

             

--3.4
--Wybieram  nazwy centr., i srednia cena za produkty laczac tabele bufet i trampoliny_centrum.
SELECT nazwa, AVG(cena_napoju+cena_edzenia) "srednia cena"
FROM bufet b INNER JOIN trampoliny_centrum t 
ON b.id_centrum =t.id_centrum
GROUP BY nazwa;

--3.5
--Wpisz nazwe centrum trampolin, gdzie w bufetach Cena napoju jest powyzej sredniej.
SELECT nazwa, adres 
FROM bufet b INNER JOIN trampoliny_centrum t 
ON b.id_centrum =t.id_centrum
WHERE cena_napoju >(SELECT AVG(cena_napoju)
                    FROM bufet)
GROUP BY nazwa, adres, cena_napoju;

                           
