set autocommit on;


ALTER SESSION SET NLS_DATE_FORMAT = 'YYYY-MM-DD'; 

DROP TABLE OSOBA cascade constraints;
DROP TABLE BUFET cascade constraints;
DROP TABLE HAL cascade constraints;
DROP TABLE KLIENT cascade constraints;
DROP TABLE PRACOWNIK cascade constraints;
DROP TABLE PRACOWNIK_BUFET cascade constraints;
DROP TABLE PRACOWNIK_HALL cascade constraints;
DROP TABLE TRAMPOLINY_CENTRUM cascade constraints;
DROP TABLE ZAWOD cascade constraints;
DROP TABLE WIZYTA_KL cascade constraints;

-- Table: Trampoliny_centrum
CREATE TABLE TRAMPOLINY_CENTRUM (
    id_centrum int  NOT NULL,
    telefon int  NOT NULL,
    nazwa varchar(100)  NOT NULL,
    adres varchar(100)  NOT NULL,
    miasto varchar(100)  NOT NULL,
    CONSTRAINT Trampoliny_centrum_pk PRIMARY KEY (id_centrum)
);

INSERT INTO TRAMPOLINY_CENTRUM VALUES (1, 157831874, 'PRYGAJ', 'st Targowa 72/Paw 31', 'Warszawa');
INSERT INTO TRAMPOLINY_CENTRUM VALUES (2, 547685614, 'WEselje', 'st Norde 25', 'Gdansk');
INSERT INTO TRAMPOLINY_CENTRUM VALUES (3, 789556561, 'Priwet Amlet', 'st Koska 78/5', 'Szczecin');
INSERT INTO TRAMPOLINY_CENTRUM VALUES (4, 8464635, 'Hunde mude', 'st FIlse 4', 'Szczecin');
INSERT INTO TRAMPOLINY_CENTRUM VALUES (5, 78457845, 'Cziecziewica', 'st Bogdana H. 32/a', 'Poznan');
INSERT INTO TRAMPOLINY_CENTRUM VALUES (6, 78457845, 'Privet Amlet', 'st Swincickij 72', 'Radom');
INSERT INTO TRAMPOLINY_CENTRUM VALUES (7, 78457845, 'Cziecziewica', 'st Skoriny 45/2', 'Warszawa');
INSERT INTO TRAMPOLINY_CENTRUM VALUES (8, 78457845, 'Zalupkin Dom', 'st Korzemitko 141', 'Sochaczew');

-- Table: Hal
CREATE TABLE Hal (
    id_hal int  NOT NULL,
    id_centrum int  NOT NULL,
    pojemnosc int  NOT NULL,
    ilosc_trampolin int  NOT NULL,
    tereny_rekreacyjne varchar(20)  NOT NULL,
    CONSTRAINT Hal_pk PRIMARY KEY (id_hal)
);

INSERT INTO HAL  VALUES (1, 1, 40, 3, 1);
INSERT INTO HAL  VALUES (2, 4, 5, 1, 0);
INSERT INTO HAL  VALUES (3, 2, 60, 8, 3);
INSERT INTO HAL  VALUES (4, 3, 50, 12, 2);
INSERT INTO HAL  VALUES (5, 4, 15, 2, 0);
INSERT INTO HAL  VALUES (6, 8, 60, 15, 4);
INSERT INTO HAL  VALUES (7, 5, 10, 1, 0);
INSERT INTO HAL  VALUES (8, 7, 10, 1, 0);
INSERT INTO HAL  VALUES (9, 6, 10, 1, 0);


-- Table: Pracownik_Hall
CREATE TABLE Pracownik_Hall (
    id_hall int  NOT NULL,
    id_pracownik int  NOT NULL,
    CONSTRAINT Pracownik_Hall_pk PRIMARY KEY (id_hall,id_pracownik)
);

INSERT INTO PRACOWNIK_HALL VALUES (1, 4);
INSERT INTO PRACOWNIK_HALL VALUES (2, 9);
INSERT INTO PRACOWNIK_HALL VALUES (3, 12);
INSERT INTO PRACOWNIK_HALL VALUES (4, 13);
INSERT INTO PRACOWNIK_HALL VALUES (5, 14);
INSERT INTO PRACOWNIK_HALL VALUES (6, 14);
INSERT INTO PRACOWNIK_HALL VALUES (7, 20);
INSERT INTO PRACOWNIK_HALL VALUES (8, 21);
INSERT INTO PRACOWNIK_HALL VALUES (9, 22);
INSERT INTO PRACOWNIK_HALL VALUES (10, 10);
INSERT INTO PRACOWNIK_HALL VALUES (11, 11);
INSERT INTO PRACOWNIK_HALL VALUES (12, 1);
INSERT INTO PRACOWNIK_HALL VALUES (13, 2);
INSERT INTO PRACOWNIK_HALL VALUES (14, 3);
INSERT INTO PRACOWNIK_HALL VALUES (15, 4);
INSERT INTO PRACOWNIK_HALL VALUES (16, 5);


-- Table: Osoba
CREATE TABLE Osoba (
    id int  NOT NULL,
    ime varchar(20)  NOT NULL,
    nazwisko varchar(20)  NOT NULL,
    wiek int  NOT NULL,
    CONSTRAINT Osoba_pk PRIMARY KEY (id)
);

INSERT INTO OSOBA (id, ime, nazwisko, wiek) VALUES (1, 'Vlad','Kron', 22);
INSERT INTO OSOBA (id, ime, nazwisko, wiek) VALUES (2, 'John','Snith', 45);
INSERT INTO OSOBA (id, ime, nazwisko, wiek) VALUES (3, 'Will','Brook', 24);
INSERT INTO OSOBA (id, ime, nazwisko, wiek) VALUES (4, 'Kola','Luksha', 19);
INSERT INTO OSOBA (id, ime, nazwisko, wiek) VALUES (5, 'Sebas','Kacz', 35);
INSERT INTO OSOBA (id, ime, nazwisko, wiek) VALUES (6, 'Anna', 'Kasper', 21);
INSERT INTO OSOBA (id, ime, nazwisko, wiek) VALUES (7, 'LILY','BROWN', 18);
INSERT INTO OSOBA (id, ime, nazwisko, wiek) VALUES (8, 'Egor', 'Fokin', 18);
INSERT INTO OSOBA (id, ime, nazwisko, wiek) VALUES (9, 'Alina', 'Kosh', 48);
INSERT INTO OSOBA (id, ime, nazwisko, wiek) VALUES (10, 'Marina', 'Brook', 24);
INSERT INTO OSOBA (id, ime, nazwisko, wiek) VALUES (11, 'Kety', 'Ket', 21);
INSERT INTO OSOBA (id, ime, nazwisko, wiek) VALUES (12, 'Bill', 'Ket', 22);
INSERT INTO OSOBA (id, ime, nazwisko, wiek) VALUES (13, 'Sherlock', 'Holmes', 28);
INSERT INTO OSOBA (id, ime, nazwisko, wiek) VALUES (14, 'Silwia', 'Sanches', 24);
INSERT INTO OSOBA (id, ime, nazwisko, wiek) VALUES (15, 'Tim', 'Hefel', 34);
INSERT INTO OSOBA (id, ime, nazwisko, wiek) VALUES (16, 'Valentin', 'Natoptysh', 19);
INSERT INTO OSOBA (id, ime, nazwisko, wiek) VALUES (17, 'Jan', 'Sobol', 26);
INSERT INTO OSOBA (id, ime, nazwisko, wiek) VALUES (18, 'Ken', 'Swod', 21);
INSERT INTO OSOBA (id, ime, nazwisko, wiek) VALUES (19, 'Ola', 'Mirnaja', 27);
INSERT INTO OSOBA (id, ime, nazwisko, wiek) VALUES (20, 'Alexa', 'Smit', 32);
INSERT INTO OSOBA (id, ime, nazwisko, wiek) VALUES (21, 'Kek', 'Kli', 25);
INSERT INTO OSOBA (id, ime, nazwisko, wiek) VALUES (22, 'Jan', 'Menaj', 27);
INSERT INTO OSOBA (id, ime, nazwisko, wiek) VALUES (23, 'Ola', 'Menaj', 30);
INSERT INTO OSOBA (id, ime, nazwisko, wiek) VALUES (24, 'Max', 'Hrugi', 41);
INSERT INTO OSOBA (id, ime, nazwisko, wiek) VALUES (26, 'Sahra', 'Prise', 18);
INSERT INTO OSOBA (id, ime, nazwisko, wiek) VALUES (27, 'Mindi', 'Dtep', 34);
INSERT INTO OSOBA (id, ime, nazwisko, wiek) VALUES (28, 'Tom', 'Hills', 38);
INSERT INTO OSOBA (id, ime, nazwisko, wiek) VALUES (29, 'Greg', 'Patson', 40);
INSERT INTO OSOBA (id, ime, nazwisko, wiek) VALUES (30, 'Ru', 'Finrkl', 20);
INSERT INTO OSOBA (id, ime, nazwisko, wiek) VALUES (31, 'Mike', 'Chiels', 50);
INSERT INTO OSOBA (id, ime, nazwisko, wiek) VALUES (32, 'Pawel', 'Migerev', 25);
INSERT INTO OSOBA (id, ime, nazwisko, wiek) VALUES (33, 'Bill', 'Vans', 26);
INSERT INTO OSOBA (id, ime, nazwisko, wiek) VALUES (34, 'Alina', 'Zeng', 57);

-- Table: Klient
CREATE TABLE Klient (
    id_klient int  NOT NULL,
    telefon int  NOT NULL,
    Osoba_id int  NOT NULL,
    CONSTRAINT Klient_pk PRIMARY KEY (id_klient)
);

INSERT INTO KLIENT (id_klient, telefon, Osoba_id) VALUES (1, 91236874, 2);
INSERT INTO KLIENT (id_klient, telefon, Osoba_id) VALUES (2, 1242634, 4);
INSERT INTO KLIENT (id_klient, telefon, Osoba_id) VALUES (3, 8451873, 6);
INSERT INTO KLIENT (id_klient, telefon, Osoba_id) VALUES (4, 46874358, 8);
INSERT INTO KLIENT (id_klient, telefon, Osoba_id) VALUES (5, 37042598, 10);
INSERT INTO KLIENT (id_klient, telefon, Osoba_id) VALUES (6, 03546728,  12);
INSERT INTO KLIENT (id_klient, telefon, Osoba_id) VALUES (7, 35426789,  14);
INSERT INTO KLIENT (id_klient, telefon, Osoba_id) VALUES (8, 6301274859, 16);
INSERT INTO KLIENT (id_klient, telefon, Osoba_id) VALUES (9, 45468074, 15);
INSERT INTO KLIENT (id_klient, telefon, Osoba_id) VALUES (10, 86745046, 13);
INSERT INTO KLIENT (id_klient, telefon, Osoba_id) VALUES (11, 76745446, 27);
INSERT INTO KLIENT (id_klient, telefon, Osoba_id) VALUES (12, 86778046, 28);
INSERT INTO KLIENT (id_klient, telefon, Osoba_id) VALUES (13, 96752046, 29);


-- Table: Pracownik
CREATE TABLE Pracownik (
    id_pracownik int  NOT NULL,
    id_zawod int  NOT NULL,
    Osoba_id int  NOT NULL,
    CONSTRAINT Pracownik_pk PRIMARY KEY (id_pracownik)
);

INSERT INTO PRACOWNIK (id_pracownik, id_zawod, Osoba_id) VALUES (1, 1, 1 );
INSERT INTO PRACOWNIK (id_pracownik, id_zawod, Osoba_id) VALUES (2, 2, 5);
INSERT INTO PRACOWNIK (id_pracownik, id_zawod, Osoba_id) VALUES (3, 1, 3);
INSERT INTO PRACOWNIK (id_pracownik, id_zawod, Osoba_id) VALUES (4, 2, 7);
INSERT INTO PRACOWNIK (id_pracownik, id_zawod, Osoba_id) VALUES (5, 3, 9);
INSERT INTO PRACOWNIK (id_pracownik, id_zawod, Osoba_id) VALUES (6, 3, 11);
INSERT INTO PRACOWNIK (id_pracownik, id_zawod, Osoba_id) VALUES (7, 6, 17);
INSERT INTO PRACOWNIK (id_pracownik, id_zawod, Osoba_id) VALUES (8, 5, 18);
INSERT INTO PRACOWNIK (id_pracownik, id_zawod, Osoba_id) VALUES (9, 6, 19);
INSERT INTO PRACOWNIK (id_pracownik, id_zawod, Osoba_id) VALUES (10, 7, 20);
INSERT INTO PRACOWNIK (id_pracownik, id_zawod, Osoba_id) VALUES (11, 7, 21);
INSERT INTO PRACOWNIK (id_pracownik, id_zawod, Osoba_id) VALUES (12, 7, 22);
INSERT INTO PRACOWNIK (id_pracownik, id_zawod, Osoba_id) VALUES (13, 6, 23);
INSERT INTO PRACOWNIK (id_pracownik, id_zawod, Osoba_id) VALUES (14, 4, 24);
INSERT INTO PRACOWNIK (id_pracownik, id_zawod, Osoba_id) VALUES (15, 5, 25);
INSERT INTO PRACOWNIK (id_pracownik, id_zawod, Osoba_id) VALUES (16, 9, 11);
INSERT INTO PRACOWNIK (id_pracownik, id_zawod, Osoba_id) VALUES (17, 10, 18);
INSERT INTO PRACOWNIK (id_pracownik, id_zawod, Osoba_id) VALUES (18, 11, 32);
INSERT INTO PRACOWNIK (id_pracownik, id_zawod, Osoba_id) VALUES (19, 10, 33);
INSERT INTO PRACOWNIK (id_pracownik, id_zawod, Osoba_id) VALUES (20, 4, 34);
INSERT INTO PRACOWNIK (id_pracownik, id_zawod, Osoba_id) VALUES (21, 8, 30);
INSERT INTO PRACOWNIK (id_pracownik, id_zawod, Osoba_id) VALUES (22, 8, 26);
 
 
 -- Table: Zawod
CREATE TABLE Zawod (
    id_zawod int  NOT NULL,
    nazwa_stanowiska varchar(20)  NOT NULL,
    wyplata int  NOT NULL,
    CONSTRAINT Zawod_pk PRIMARY KEY (id_zawod)
);

INSERT INTO ZAWOD (id_zawod, nazwa_stanowiska, wyplata) VALUES (1,'Ochroniarz', 5000);
INSERT INTO ZAWOD (id_zawod, nazwa_stanowiska, wyplata) VALUES (2,'Ochroniarz', 2000);
INSERT INTO ZAWOD (id_zawod, nazwa_stanowiska, wyplata) VALUES (3,'Sprzatacz', 4500);
INSERT INTO ZAWOD (id_zawod, nazwa_stanowiska, wyplata) VALUES (4,'Sprzatacz', 4300);
INSERT INTO ZAWOD (id_zawod, nazwa_stanowiska, wyplata) VALUES (5, 'Menedzer', 5600);
INSERT INTO ZAWOD (id_zawod, nazwa_stanowiska, wyplata) VALUES (6, 'Menedzer', 6600);
INSERT INTO ZAWOD (id_zawod, nazwa_stanowiska, wyplata) VALUES (7, 'instruktor', 6000);
INSERT INTO ZAWOD (id_zawod, nazwa_stanowiska, wyplata) VALUES (8, 'dyrektor', 12000);
INSERT INTO ZAWOD (id_zawod, nazwa_stanowiska, wyplata) VALUES (9, 'sprzedawca', 5000);
INSERT INTO ZAWOD (id_zawod, nazwa_stanowiska, wyplata) VALUES (10, 'sprzedawca', 6000);
INSERT INTO ZAWOD (id_zawod, nazwa_stanowiska, wyplata) VALUES (11, 'sprzedawca', 5700);

-- tables
-- Table: Bufet
CREATE TABLE Bufet (
    id_bufet int  NOT NULL,
    id_centrum int  NOT NULL,
    nopoj varchar(20)  NOT NULL,
    cena_napoju int  NOT NULL,
    jedzenie varchar(20)  NOT NULL,
    cena_edzenia int  NOT NULL,
    CONSTRAINT Bufet_pk PRIMARY KEY (id_bufet)
);

INSERT INTO BUFET VALUES (1, 1,'COLA', 5, 'PIZZA', 23);
INSERT INTO BUFET VALUES (2, 2,'PEPSI', 4, 'NACHOS', 20);
INSERT INTO BUFET VALUES (3, 1, 'FANTA', 3, 'PIZZA SER', 18);
INSERT INTO BUFET VALUES (4, 3, 'MIRINDA', 7, 'SUSHI*2', 37);
INSERT INTO BUFET VALUES (5, 4, 'COLA', 3,' SALAD OWOC', 19);
INSERT INTO BUFET VALUES (6, 7, 'JUICE', 9, 'SALAD', 34);
INSERT INTO BUFET VALUES (7, 5, 'SCHWEPPES 0,5 ', 6, 'PIZZA MAr', 19);
INSERT INTO BUFET VALUES (8, 2, 'COLA ZERO', 5, 'KEBAB', 12);
INSERT INTO BUFET VALUES (9, 4, 'SCHWEPPES 1L', 4, 'SUSHI', 27);
INSERT INTO BUFET VALUES (10, 3, 'MIRINDA xL', 4, 'SALAD TER', 20);


-- Table: Pracownik_Bufet
CREATE TABLE Pracownik_Bufet (
    id_bufet int  NOT NULL,
    id_pracownik int  NOT NULL,
    CONSTRAINT Pracownik_Bufet_pk PRIMARY KEY (id_bufet,id_pracownik)
);

INSERT INTO PRACOWNIK_BUFET VALUES (1,  1);
INSERT INTO PRACOWNIK_BUFET VALUES (6,  1);
INSERT INTO PRACOWNIK_BUFET VALUES (2,  2);
INSERT INTO PRACOWNIK_BUFET VALUES (3,  2);
INSERT INTO PRACOWNIK_BUFET VALUES (4,  3);
INSERT INTO PRACOWNIK_BUFET VALUES (10, 3);
INSERT INTO PRACOWNIK_BUFET VALUES (9,  8);
INSERT INTO PRACOWNIK_BUFET VALUES (8,  11);
INSERT INTO PRACOWNIK_BUFET VALUES (10,  18);
INSERT INTO PRACOWNIK_BUFET VALUES (2,  19);
INSERT INTO PRACOWNIK_BUFET VALUES (7,  17);
 

-- Table: Wizyta
CREATE TABLE Wizyta_kl (
    id_wizyta int  NOT NULL,
    id_klient int  NOT NULL,
    id_centrum int  NOT NULL,
    poczatek_wizyty timestamp  NOT NULL,
    koniec_wizyty timestamp  NOT NULL,
    CONSTRAINT id_wizyta_pk PRIMARY KEY (id_wizyta,id_klient,id_centrum)
);
INSERT INTO WIZYTA_KL (id_wizyta, id_centrum, id_klient, poczatek_wizyty, koniec_wizyty)  VALUES (1, 2, 10, TIMESTAMP '2021-05-10 18:45:00', TIMESTAMP '2021-05-01 20:05:00');
INSERT INTO WIZYTA_KL (id_wizyta, id_centrum, id_klient, poczatek_wizyty, koniec_wizyty) VALUES (2, 5, 8, TIMESTAMP '2021-04-01 18:45:00', TIMESTAMP '2021-04-01 20:05:00');
INSERT INTO WIZYTA_KL (id_wizyta, id_centrum, id_klient, poczatek_wizyty, koniec_wizyty) VALUES (3, 3, 9, TIMESTAMP '2021-02-02 13:45:00', TIMESTAMP '2021-02-02 15:15:00');
INSERT INTO WIZYTA_KL (id_wizyta, id_centrum, id_klient, poczatek_wizyty, koniec_wizyty)  VALUES (4, 1, 7, TIMESTAMP '2021-05-22 09:45:00', TIMESTAMP '2021-05-22 11:05:00');
INSERT INTO WIZYTA_KL (id_wizyta, id_centrum, id_klient, poczatek_wizyty, koniec_wizyty) VALUES (5, 4, 6, TIMESTAMP '2021-05-23 17:45:00', TIMESTAMP '2021-05-23 19:05:00');
INSERT INTO WIZYTA_KL (id_wizyta, id_centrum, id_klient, poczatek_wizyty, koniec_wizyty) VALUES (6, 8, 5, TIMESTAMP '2021-01-13 15:45:00', TIMESTAMP '2021-01-13 20:05:00');
INSERT INTO WIZYTA_KL (id_wizyta, id_centrum, id_klient, poczatek_wizyty, koniec_wizyty) VALUES (7, 7, 4, TIMESTAMP '2021-03-24 13:45:00', TIMESTAMP '2021-03-24 18:00:00');
INSERT INTO WIZYTA_KL (id_wizyta, id_centrum, id_klient, poczatek_wizyty, koniec_wizyty) VALUES (8, 6, 3, TIMESTAMP '2021-03-14 13:45:00', TIMESTAMP '2021-03-14 15:05:00');
INSERT INTO WIZYTA_KL (id_wizyta, id_centrum, id_klient, poczatek_wizyty, koniec_wizyty) VALUES (9, 4, 2, TIMESTAMP '2021-02-01 14:45:00', TIMESTAMP '2021-02-01 15:05:00');
INSERT INTO WIZYTA_KL (id_wizyta, id_centrum, id_klient, poczatek_wizyty, koniec_wizyty) VALUES (10, 8, 11, TIMESTAMP '2021-05-01 14:45:00', TIMESTAMP '2021-05-01 15:05:00');
INSERT INTO WIZYTA_KL (id_wizyta, id_centrum, id_klient, poczatek_wizyty, koniec_wizyty) VALUES (11, 6, 12, TIMESTAMP '2021-05-12 15:00:00', TIMESTAMP '2021-05-12 18:00:00');
INSERT INTO WIZYTA_KL (id_wizyta, id_centrum, id_klient, poczatek_wizyty, koniec_wizyty) VALUES (12, 4, 2, TIMESTAMP '2021-05-13 11:20:00', TIMESTAMP '2021-05-13 15:10:00');
INSERT INTO WIZYTA_KL (id_wizyta, id_centrum, id_klient, poczatek_wizyty, koniec_wizyty) VALUES (13, 5, 13, TIMESTAMP '2021-06-01 17:00:00', TIMESTAMP '2021-06-01 19:05:00');
INSERT INTO WIZYTA_KL (id_wizyta, id_centrum, id_klient, poczatek_wizyty, koniec_wizyty) VALUES (14, 5, 12, TIMESTAMP '2021-05-06 16:00:00', TIMESTAMP '2021-06-06 20:35:00');
INSERT INTO WIZYTA_KL (id_wizyta, id_centrum, id_klient, poczatek_wizyty, koniec_wizyty) VALUES (15, 2, 11, TIMESTAMP '2021-06-07 16:20:00', TIMESTAMP '2021-06-07 20:15:00');
INSERT INTO WIZYTA_KL (id_wizyta, id_centrum, id_klient, poczatek_wizyty, koniec_wizyty) VALUES (16, 1, 10, TIMESTAMP '2021-06-07 15:30:00', TIMESTAMP '2021-06-07 18:45:00');
INSERT INTO WIZYTA_KL (id_wizyta, id_centrum, id_klient, poczatek_wizyty, koniec_wizyty) VALUES (17, 8, 1, TIMESTAMP '2021-03-14 13:45:00', TIMESTAMP '2021-03-14 15:05:00');







