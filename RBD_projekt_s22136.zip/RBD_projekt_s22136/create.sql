-- Created by Vertabelo (http://vertabelo.com)
-- Last modification date: 2021-06-24 19:34:29.086

-- tables
-- Table: Bufet
CREATE TABLE Bufet (
    id_bufet int  NOT NULL,
    Trampoliny_centrum_id_centrum int  NOT NULL,
    nopoj varchar(20)  NOT NULL,
    cena_napoju int  NOT NULL,
    jedzenie varchar(20)  NOT NULL,
    cena_edzenia int  NOT NULL,
    CONSTRAINT Bufet_pk PRIMARY KEY (id_bufet)
);

-- Table: Hal
CREATE TABLE Hal (
    id_hal int  NOT NULL,
    id_centrum int  NOT NULL,
    pojemnosc int  NOT NULL,
    ilosc_trampolin int  NOT NULL,
    tereny_rekreacyjne varchar(20)  NOT NULL,
    CONSTRAINT Hal_pk PRIMARY KEY (id_hal)
);

-- Table: Klient
CREATE TABLE Klient (
    id_klient int  NOT NULL,
    telefon int  NOT NULL,
    Osoba_id int  NOT NULL,
    CONSTRAINT Klient_pk PRIMARY KEY (id_klient)
);

-- Table: Osoba
CREATE TABLE Osoba (
    id int  NOT NULL,
    ime varchar(20)  NOT NULL,
    nazwisko varchar(20)  NOT NULL,
    wiek int  NOT NULL,
    CONSTRAINT Osoba_pk PRIMARY KEY (id)
);

-- Table: Pracownik
CREATE TABLE Pracownik (
    id_pracownik int  NOT NULL,
    id_zawod int  NOT NULL,
    Osoba_id int  NOT NULL,
    CONSTRAINT Pracownik_pk PRIMARY KEY (id_pracownik)
);

-- Table: Pracownik_Bufet
CREATE TABLE Pracownik_Bufet (
    id_bufet int  NOT NULL,
    id_pracownik int  NOT NULL,
    CONSTRAINT Pracownik_Bufet_pk PRIMARY KEY (id_bufet,id_pracownik)
);

-- Table: Pracownik_Hall
CREATE TABLE Pracownik_Hall (
    id_hall int  NOT NULL,
    id_pracownik int  NOT NULL,
    CONSTRAINT Pracownik_Hall_pk PRIMARY KEY (id_hall,id_pracownik)
);

-- Table: Trampoliny_centrum
CREATE TABLE Trampoliny_centrum (
    id_centrum int  NOT NULL,
    telefon int  NOT NULL,
    nazwa varchar(40)  NOT NULL,
    adres varchar(40)  NOT NULL,
    miasto varchar(30)  NOT NULL,
    CONSTRAINT Trampoliny_centrum_pk PRIMARY KEY (id_centrum)
);

-- Table: Wizyta_kl
CREATE TABLE Wizyta_kl (
    id_wizyta int  NOT NULL,
    id_klient int  NOT NULL,
    id_centrum int  NOT NULL,
    poczatek_wizyty timestamp  NOT NULL,
    koniec_wizyty timestamp  NOT NULL,
    CONSTRAINT Wizyta_kl_pk PRIMARY KEY (id_wizyta,id_klient,id_centrum)
);

-- Table: Zawod
CREATE TABLE Zawod (
    id_zawod int  NOT NULL,
    nazwa_stanowiska varchar(20)  NOT NULL,
    wyplata int  NOT NULL,
    CONSTRAINT Zawod_pk PRIMARY KEY (id_zawod)
);

-- foreign keys
-- Reference: Bufet_Trampoliny_centrum (table: Bufet)
ALTER TABLE Bufet ADD CONSTRAINT Bufet_Trampoliny_centrum
    FOREIGN KEY (Trampoliny_centrum_id_centrum)
    REFERENCES Trampoliny_centrum (id_centrum)  
    NOT DEFERRABLE 
    INITIALLY IMMEDIATE
;

-- Reference: Hall_Trampoliny_centrum (table: Hal)
ALTER TABLE Hal ADD CONSTRAINT Hall_Trampoliny_centrum
    FOREIGN KEY (id_centrum)
    REFERENCES Trampoliny_centrum (id_centrum)  
    NOT DEFERRABLE 
    INITIALLY IMMEDIATE
;

-- Reference: Klient_Osoba (table: Klient)
ALTER TABLE Klient ADD CONSTRAINT Klient_Osoba
    FOREIGN KEY (Osoba_id)
    REFERENCES Osoba (id)  
    NOT DEFERRABLE 
    INITIALLY IMMEDIATE
;

-- Reference: Personel_Bufet_Bufet (table: Pracownik_Bufet)
ALTER TABLE Pracownik_Bufet ADD CONSTRAINT Personel_Bufet_Bufet
    FOREIGN KEY (id_bufet)
    REFERENCES Bufet (id_bufet)  
    NOT DEFERRABLE 
    INITIALLY IMMEDIATE
;

-- Reference: Personel_Bufet_Personel (table: Pracownik_Bufet)
ALTER TABLE Pracownik_Bufet ADD CONSTRAINT Personel_Bufet_Personel
    FOREIGN KEY (id_pracownik)
    REFERENCES Pracownik (id_pracownik)  
    NOT DEFERRABLE 
    INITIALLY IMMEDIATE
;

-- Reference: Personel_Hall_Personel (table: Pracownik_Hall)
ALTER TABLE Pracownik_Hall ADD CONSTRAINT Personel_Hall_Personel
    FOREIGN KEY (id_pracownik)
    REFERENCES Pracownik (id_pracownik)  
    NOT DEFERRABLE 
    INITIALLY IMMEDIATE
;

-- Reference: Personel_Zawod (table: Pracownik)
ALTER TABLE Pracownik ADD CONSTRAINT Personel_Zawod
    FOREIGN KEY (id_zawod)
    REFERENCES Zawod (id_zawod)  
    NOT DEFERRABLE 
    INITIALLY IMMEDIATE
;

-- Reference: Personele_Hall_Hall (table: Pracownik_Hall)
ALTER TABLE Pracownik_Hall ADD CONSTRAINT Personele_Hall_Hall
    FOREIGN KEY (id_hall)
    REFERENCES Hal (id_hal)  
    NOT DEFERRABLE 
    INITIALLY IMMEDIATE
;

-- Reference: Pracownik_Osoba (table: Pracownik)
ALTER TABLE Pracownik ADD CONSTRAINT Pracownik_Osoba
    FOREIGN KEY (Osoba_id)
    REFERENCES Osoba (id)  
    NOT DEFERRABLE 
    INITIALLY IMMEDIATE
;

-- Reference: Wizyta_Klient (table: Wizyta_kl)
ALTER TABLE Wizyta_kl ADD CONSTRAINT Wizyta_Klient
    FOREIGN KEY (id_klient)
    REFERENCES Klient (id_klient)  
    NOT DEFERRABLE 
    INITIALLY IMMEDIATE
;

-- Reference: Wizyta_Trampoliny_centrum (table: Wizyta_kl)
ALTER TABLE Wizyta_kl ADD CONSTRAINT Wizyta_Trampoliny_centrum
    FOREIGN KEY (id_centrum)
    REFERENCES Trampoliny_centrum (id_centrum)  
    NOT DEFERRABLE 
    INITIALLY IMMEDIATE
;

-- End of file.

